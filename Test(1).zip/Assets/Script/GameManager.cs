﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditorInternal;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject menuCam;
    public GameObject gameCam;
    public Player player;
    public Boss boss;
    public Shop shop;
    public GameObject portal;
    public GameObject[] portals;
    public GameObject startZone;
    public int field = 1;
    public float playTime;
    public float dungeonTime;
    public bool isBattle;
    public int enemyCntA;
    public int enemyCntB;
    public int enemyCntC;

    public Transform[] enemyZones;
    public GameObject[] enemies;
    public List<int> enemyList;

    public GameObject menuPanel;    
    public GameObject gamePanel;
    public GameObject overPanel;
    public Text maxScoreTxt;
    public Text scoreTxt;
    public Text stageTxt;
    public Text playTimeTxt;
    public Text playerHealthTxt;
    public Text playerAmmoTxt;
    public Text playerCoinTxt;
    public Image weapon1Img;
    public Image weapon2Img;
    public Image weapon3Img;
    public Text enemyATxt;
    public Text enemyBTxt;
    public Text enemyCTxt;
    public Image[] weaponImage;
    public Text weaponAmmo;
    public RectTransform bossHealthGroup;
    public RectTransform bossHealthBar;
    public Text curScoreText;
    public Text bestText;

    void Awake()
    {
        enemyList = new List<int>();
        maxScoreTxt.text = string.Format("{0:n0}", PlayerPrefs.GetInt("MaxScore"));
    }

    public void GameStart()
    {
        menuCam.SetActive(false);
        gameCam.SetActive(true);

        menuPanel.SetActive(false);
        gamePanel.SetActive(true);

        player.gameObject.SetActive(true);

        playTime = 0;
    }
    public void StageStart()
    {
        foreach (GameObject pt in portals)
        {
            pt.SetActive(false);
        }
        startZone.SetActive(false);

        foreach (Transform zone in enemyZones)
            zone.gameObject.SetActive(false);

        isBattle = true;
        StartCoroutine(InBattle());
    }
    public void StageEnd()
    {
        foreach (GameObject pt in portals)
        {
            pt.SetActive(true);
        }
        startZone.SetActive(true);
        field++;
        isBattle = false;
    }
    IEnumerator InBattle()
    {
        if (field % 5 == 0)
        {
            //enemyCntD++;
            GameObject instantEnemy = Instantiate(enemies[3], enemyZones[0].position, enemyZones[0].rotation);
            Enemy enemy = instantEnemy.GetComponent<Enemy>();
            enemy.target = player.transform;
            enemy.manager = this;
            boss = instantEnemy.GetComponent<Boss>();
        }
        else
        {
            for (int i = 0; i < field; i++)
            {
                int ran = Random.Range(0, 3);
                enemyList.Add(ran);

                switch (ran)
                {
                    case 0:
                        enemyCntA++;
                        break;
                    case 1:
                        enemyCntB++;
                        break;
                    case 2:
                        enemyCntC++;
                        break;
                }
            }

            while (enemyList.Count > 0)
            {
                int ranZone = Random.Range(0, 4);
                GameObject instantEnemy = Instantiate(enemies[enemyList[0]], enemyZones[ranZone].position, enemyZones[ranZone].rotation);
                Enemy enemy = instantEnemy.GetComponent<Enemy>();
                enemy.target = player.transform;
                enemy.manager = this;
                enemyList.RemoveAt(0);
                yield return new WaitForSeconds(5);
            }
        }
        while (enemyCntA + enemyCntB + enemyCntC > 0)
        {
            yield return null;
        }
        yield return new WaitForSeconds(4f);
        dungeonTime = 0;
        boss = null;
        StageEnd();
    }
    void Update()
    {
        playTime += Time.deltaTime;
        if (isBattle)
            dungeonTime += Time.deltaTime;
    }
    void LateUpdate()
    {
        scoreTxt.text = string.Format("{0:n0}", player.score);
        //stageTxt.text = "필드 : " + field;
        
        
        if (isBattle)
        {
            int hour = (int)(dungeonTime / 3600);
            int min = (int)((dungeonTime - (hour * 3600)) / 60);
            int sec = (int)dungeonTime % 60;
            playTimeTxt.text = string.Format("{0:00}", hour) + ":" + string.Format("{0:00}", min) + ":" + string.Format("{0:00}", sec);

        }
        else
        {
            int hour = (int)(playTime / 3600);
            int min = (int)((playTime - (hour * 3600)) / 60);
            int sec = (int)playTime % 60;
            playTimeTxt.text = string.Format("{0:00}", hour) + ":" + string.Format("{0:00}", min) + ":" + string.Format("{0:00}", sec);

        }

        playerHealthTxt.text = player.health + " / " + player.maxHealth;
        playerCoinTxt.text = string.Format("{0:n0}", player.coin);
        playerAmmoTxt.text =  player.ammo + " / " + player.maxAmmo;

        weapon1Img.color = new Color(1, 1, 1, player.hasWeapons[0] ? 1 : 0);
        weapon2Img.color = new Color(1, 1, 1, player.hasWeapons[1] ? 1 : 0);
        weapon3Img.color = new Color(1, 1, 1, player.hasWeapons[2] ? 1 : 0);

        enemyATxt.text = enemyCntA.ToString();
        enemyBTxt.text = enemyCntB.ToString();
        enemyCTxt.text = enemyCntC.ToString();

        if (boss != null)
        {
            bossHealthGroup.gameObject.SetActive(true);
            bossHealthBar.localScale = new Vector3((float)boss.curHealth / (float)boss.maxHealth, 1, 1);
        }
        else
        {
            bossHealthGroup.gameObject.SetActive(false);
        }


        if (player.equipWeapon == null && player.equipWeaponIndex == -1)
        {
            weaponAmmo.gameObject.SetActive(false);
            return;
        }
        else
        {
            weaponAmmo.gameObject.SetActive(true);
            if (player.equipWeaponIndex == 0)
            {
                weaponImage[0].gameObject.SetActive(true);
                weaponImage[1].gameObject.SetActive(false);
                weaponImage[2].gameObject.SetActive(false);
                weaponAmmo.text = "- / -";
            }
            else if (player.equipWeaponIndex == 1)
            {
                weaponImage[0].gameObject.SetActive(false);
                weaponImage[1].gameObject.SetActive(true);
                weaponImage[2].gameObject.SetActive(false);
                weaponAmmo.text = player.equipWeapon.curAmmo + " / " + player.equipWeapon.maxAmmo;
            }
            else if (player.equipWeaponIndex == 2)
            {
                weaponImage[0].gameObject.SetActive(false);
                weaponImage[1].gameObject.SetActive(false);
                weaponImage[2].gameObject.SetActive(true);
                weaponAmmo.text = player.equipWeapon.curAmmo + " / " + player.equipWeapon.maxAmmo;
            }
        } 
    }  
    public void GameOver()
    {
        gamePanel.SetActive(false);
        overPanel.SetActive(true);
        curScoreText.text = scoreTxt.text;

        int maxScore = PlayerPrefs.GetInt("MaxScore");
        if(player.score > maxScore)
        {
            bestText.gameObject.SetActive(true);
            PlayerPrefs.SetInt("MaxScore", player.score);
        }
    }

    public void Restart()
    {
        SceneManager.LoadScene(0);
    }
}
