﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class FarmFloor : MonoBehaviour
{

    public bool isCheck;
    private void OnTriggerStay(Collider other)
    {
        if(other.tag == "Check")
        {
            isCheck = true;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Check")
        {
            isCheck = false;
        }
    }
}
