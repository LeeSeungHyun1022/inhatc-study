﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FarmCheck : MonoBehaviour
{
    public Player player;
    public Camera followCamera;
    public FarmFloor[] farms;

    GameObject nearObj;

    bool isRange;
    bool isUse;

    private void Update()
    {
        Trans();
        Rang();
        Check();
    }

    void Trans()
    {
        Ray ray = followCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit hitinfo;

        if (Physics.Raycast(ray, out hitinfo, 100))
        {
            Vector3 nextVec = hitinfo.point;

            nextVec = new Vector3((int)nextVec.x, 0, (int)nextVec.z);
            
            if (nextVec.x % 10 == 0 || nextVec.z % 10 == 0)
            {
                nextVec.y = -10;
            }
            else
            {
                nextVec.y = 0;
            }

            
            transform.position = nextVec;
        }
        //오류하나 겹치는 부분이 없게 해야함 꼭지점 부분이 겹침 
    }

    void Rang()
    {
        RaycastHit[] rayHits = Physics.SphereCastAll(player.transform.position,
                                                            5f,
                                                            player.transform.forward,
                                                            0f,
                                                            LayerMask.GetMask("Check"));
        //Debug.DrawRay(player.transform.position, transform.forward * 5, Color.green);
        if (rayHits.Length == 1)
        {
            isRange = true;
        }
        else
        {
            isRange = false;
        }
    }

    void Check()
    {
        foreach (FarmFloor farm in farms)
            if (isRange && farm.isCheck)
            {
                farm.GetComponent<MeshRenderer>().material.color = Color.red;
                isUse = true;
            }
            else
            {
                farm.GetComponent<MeshRenderer>().material.color = Color.white;
                isUse = false;
            }
    }

    //hasSeed > 0
    //isUse = true일때 hasSeed -= 1하고 땅을 심어져있는 땅으로 바꾼다
    //심어진 땅은 시간에 따라 자라고 다 자라면 더이상 자라지 않으며 오랜 시간 방치하면 사라진다
    //또한 낫으로만 수확가능하다 낫으로 클릭하면 심어져잇는땅에서 다시 그냥 땅으로 바뀐다
    //또한 음식을 씨앗으로도 바꿀수잇고 먹을수 잇게 설정
    
}
