﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Portal : MonoBehaviour
{
    public GameObject uiGroup;
    public RectTransform uiGroupVec;
    public GameObject player;

    public Transform[] teleportPos;

    Player enterPlayer;
    public void Enter(Player player)
    {
        enterPlayer = player;
        uiGroup.SetActive(true);
        uiGroupVec.anchoredPosition = Vector3.zero;
    }

    public void Exit()
    {
        uiGroupVec.anchoredPosition = Vector3.up * 1000;
        uiGroup.SetActive(false);
    }

    public void Teleport(int index)
    {
        player.transform.position = teleportPos[index].position;
    }
}
